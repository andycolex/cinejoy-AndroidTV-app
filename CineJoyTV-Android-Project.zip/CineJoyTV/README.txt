CineJoy TV (Android TV / Google TV / Fire TV) - WebView app for https://cinejoy.pk
BUILD: Android Studio (JDK 17) > Build APK, or push to GitHub (workflow in .github) and download the "CineJoyTV-apk" artifact.
REMOTE: D-pad = move focus, OK = select, Back = back (hold Back or press Menu/Settings/Yellow = app menu),
        Play/Pause/FF/RW keys control the video. Menu has mouse-pointer mode, text size, reload, home, exit.
INSTALL: adb connect <tv-ip>:5555 ; adb install app-debug.apk   (or copy to USB / use the "Downloader" app).
