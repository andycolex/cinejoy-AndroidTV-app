package pk.cinejoy.tv

import android.Manifest
import android.annotation.SuppressLint
import android.app.DownloadManager
import android.content.*
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Color
import android.net.ConnectivityManager
import android.net.Network
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.Environment
import android.view.KeyEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.webkit.*
import android.widget.Button
import android.widget.FrameLayout
import android.widget.ProgressBar
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.ContextCompat
import androidx.core.splashscreen.SplashScreen.Companion.installSplashScreen
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat

class MainActivity : AppCompatActivity() {

    private val home = "https://cinejoy.pk"
    private val allowedHosts = setOf("cinejoy.pk", "www.cinejoy.pk")

    private lateinit var web: WebView
    private lateinit var progress: ProgressBar
    private lateinit var errorView: View
    private lateinit var retryBtn: Button
    private lateinit var navJs: String
    private lateinit var prefs: SharedPreferences

    private var customView: View? = null
    private var customCallback: WebChromeClient.CustomViewCallback? = null
    private var pendingDownload: (() -> Unit)? = null
    private var netCb: ConnectivityManager.NetworkCallback? = null
    private var lastBack = 0L
    private var longBack = false
    private var failed = false
    private var crashed = false
    private var cursorMode = false
    private var textZoom = 110   // 10-foot readability; adjustable from the in-app menu

    private val storagePerm = registerForActivityResult(ActivityResultContracts.RequestPermission()) { ok ->
        if (ok) pendingDownload?.invoke() else toast(getString(R.string.permission_denied))
        pendingDownload = null
    }

    private val downloadDone = object : BroadcastReceiver() {
        override fun onReceive(c: Context, i: Intent) {
            val id = i.getLongExtra(DownloadManager.EXTRA_DOWNLOAD_ID, -1L)
            getSystemService(DownloadManager::class.java).query(DownloadManager.Query().setFilterById(id)).use { q ->
                if (q.moveToFirst()) {
                    val ok = q.getInt(q.getColumnIndexOrThrow(DownloadManager.COLUMN_STATUS)) == DownloadManager.STATUS_SUCCESSFUL
                    val title = q.getString(q.getColumnIndexOrThrow(DownloadManager.COLUMN_TITLE)) ?: ""
                    toast(getString(if (ok) R.string.download_done else R.string.download_failed, title))
                }
            }
        }
    }

    @SuppressLint("SetJavaScriptEnabled")
    override fun onCreate(savedInstanceState: Bundle?) {
        installSplashScreen()
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        prefs = getSharedPreferences("tv", MODE_PRIVATE)
        textZoom = prefs.getInt("zoom", 110)
        navJs = assets.open("tv_nav.js").bufferedReader().use { it.readText() }

        web = findViewById(R.id.web); progress = findViewById(R.id.progress)
        errorView = findViewById(R.id.error); retryBtn = findViewById(R.id.retry)
        retryBtn.setOnClickListener { retry() }
        web.setBackgroundColor(Color.BLACK)
        if (applicationInfo.flags and ApplicationInfo.FLAG_DEBUGGABLE != 0) WebView.setWebContentsDebuggingEnabled(true)
        setBars(false)

        web.settings.apply {
            javaScriptEnabled = true
            domStorageEnabled = true
            mediaPlaybackRequiresUserGesture = false
            allowFileAccess = false
            allowContentAccess = false
            loadWithOverviewMode = true
            useWideViewPort = true
            textZoom = this@MainActivity.textZoom
            mixedContentMode = WebSettings.MIXED_CONTENT_COMPATIBILITY_MODE
            // Present as a TV/desktop-class browser so the site serves its large-screen layout
            userAgentString = userAgentString.replace(" Mobile", "") + " CineJoyTV/1.0 AndroidTV"
        }
        CookieManager.getInstance().apply { setAcceptCookie(true); setAcceptThirdPartyCookies(web, true) }

        web.webViewClient = object : WebViewClient() {
            override fun shouldOverrideUrlLoading(v: WebView, r: WebResourceRequest): Boolean {
                val u = r.url
                if (u.scheme in listOf("http", "https") && u.host in allowedHosts) return false
                try { startActivity(Intent(Intent.ACTION_VIEW, u)) } catch (_: ActivityNotFoundException) {}
                return true
            }
            override fun onPageStarted(v: WebView, url: String?, f: Bitmap?) { failed = false; cursorMode = false }
            override fun onPageFinished(v: WebView, url: String?) {
                v.evaluateJavascript(navJs, null)
                showError(failed)
                CookieManager.getInstance().flush()
            }
            override fun onReceivedError(v: WebView, r: WebResourceRequest, e: WebResourceError) {
                if (r.isForMainFrame) { failed = true; showError(true) }
            }
            override fun onRenderProcessGone(v: WebView, d: RenderProcessGoneDetail): Boolean {
                crashed = true; (v.parent as? ViewGroup)?.removeView(v); v.destroy(); recreate(); return true
            }
        }
        web.webChromeClient = object : WebChromeClient() {
            override fun onProgressChanged(v: WebView, p: Int) {
                progress.progress = p; progress.visibility = if (p in 1..99) View.VISIBLE else View.GONE
            }
            override fun onShowCustomView(view: View, cb: CustomViewCallback) {
                if (customView != null) { cb.onCustomViewHidden(); return }
                customView = view; customCallback = cb
                (window.decorView as FrameLayout).addView(view, ViewGroup.LayoutParams(-1, -1))
                window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
            }
            override fun onHideCustomView() {
                customView?.let { (window.decorView as FrameLayout).removeView(it) }
                customView = null; customCallback?.onCustomViewHidden(); customCallback = null
                window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
                web.requestFocus()
            }
        }
        web.setDownloadListener { url, ua, cd, mime, _ -> download(url, ua, cd, mime) }

        ContextCompat.registerReceiver(this, downloadDone, IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE), ContextCompat.RECEIVER_EXPORTED)
        try {
            netCb = object : ConnectivityManager.NetworkCallback() {
                override fun onAvailable(n: Network) { if (failed) runOnUiThread { retry() } }
            }
            getSystemService(ConnectivityManager::class.java).registerDefaultNetworkCallback(netCb!!)
        } catch (_: Exception) {}

        val restored = savedInstanceState?.let { web.restoreState(it) }
        if (restored == null) web.loadUrl(targetUrl(intent) ?: home)
        web.requestFocus()
    }

    override fun onNewIntent(intent: Intent) { super.onNewIntent(intent); targetUrl(intent)?.let { web.loadUrl(it) } }

    private fun targetUrl(i: Intent?): String? {
        val u = i?.data?.toString() ?: return null
        val p = Uri.parse(u)
        return u.takeIf { p.scheme == "https" && p.host in allowedHosts }
    }

    private fun retry() { failed = false; showError(false); web.loadUrl(web.url?.takeIf { it.startsWith("http") } ?: home) }

    private fun showError(show: Boolean) {
        errorView.visibility = if (show) View.VISIBLE else View.GONE
        web.isFocusable = !show
        if (show) retryBtn.requestFocus() else if (customView == null) web.requestFocus()
    }

    private fun js(s: String) = web.evaluateJavascript("window.__cj&&$s", null)

    // ---- Remote control -------------------------------------------------------------------
    override fun dispatchKeyEvent(e: KeyEvent): Boolean {
        if (e.action == KeyEvent.ACTION_DOWN) {
            val first = e.repeatCount == 0
            when (e.keyCode) {
                KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE -> { if (first) js("__cj.media('toggle')"); return true }
                KeyEvent.KEYCODE_MEDIA_PLAY -> { js("__cj.media('play')"); return true }
                KeyEvent.KEYCODE_MEDIA_PAUSE -> { js("__cj.media('pause')"); return true }
                KeyEvent.KEYCODE_MEDIA_FAST_FORWARD -> { js("__cj.media('seek',30)"); return true }
                KeyEvent.KEYCODE_MEDIA_REWIND -> { js("__cj.media('seek',-10)"); return true }
                KeyEvent.KEYCODE_MENU, KeyEvent.KEYCODE_SETTINGS, KeyEvent.KEYCODE_PROG_YELLOW ->
                    { if (first) showMenu(); return true }
            }
            if (customView != null) when (e.keyCode) {   // native fullscreen video: remote controls the player
                KeyEvent.KEYCODE_DPAD_RIGHT -> { js("__cj.media('seek',10)"); return true }
                KeyEvent.KEYCODE_DPAD_LEFT -> { js("__cj.media('seek',-10)"); return true }
                KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER -> { if (first) js("__cj.media('toggle')"); return true }
            }
        }
        return super.dispatchKeyEvent(e)
    }

    override fun onKeyDown(k: Int, e: KeyEvent): Boolean {
        if (k == KeyEvent.KEYCODE_BACK) { e.startTracking(); return true }
        return super.onKeyDown(k, e)
    }
    override fun onKeyLongPress(k: Int, e: KeyEvent): Boolean {
        if (k == KeyEvent.KEYCODE_BACK) { longBack = true; showMenu(); return true }
        return super.onKeyLongPress(k, e)
    }
    override fun onKeyUp(k: Int, e: KeyEvent): Boolean {
        if (k == KeyEvent.KEYCODE_BACK) { if (longBack) longBack = false else goBack(); return true }
        return super.onKeyUp(k, e)
    }

    private fun goBack() {
        when {
            customView != null -> web.webChromeClient?.onHideCustomView()
            web.canGoBack() -> web.goBack()
            System.currentTimeMillis() - lastBack < 2000 -> finish()
            else -> { lastBack = System.currentTimeMillis(); toast(getString(R.string.press_back_again)) }
        }
    }

    private fun showMenu() {
        val items = arrayOf(
            getString(R.string.m_reload), getString(R.string.m_home),
            getString(if (cursorMode) R.string.m_cursor_off else R.string.m_cursor_on),
            getString(R.string.m_text_up, textZoom), getString(R.string.m_text_down), getString(R.string.m_exit))
        AlertDialog.Builder(this).setTitle(R.string.m_title).setItems(items) { _, i ->
            when (i) {
                0 -> web.reload()
                1 -> web.loadUrl(home)
                2 -> { cursorMode = !cursorMode; js("__cj.cursor($cursorMode)") }
                3 -> zoom(+10)
                4 -> zoom(-10)
                5 -> finish()
            }
        }.show()
    }

    private fun zoom(d: Int) {
        textZoom = (textZoom + d).coerceIn(70, 200)
        web.settings.textZoom = textZoom
        prefs.edit().putInt("zoom", textZoom).apply()
        toast("$textZoom%")
    }

    // ---- Downloads ------------------------------------------------------------------------
    private fun download(url: String, ua: String?, cd: String?, mime: String?) {
        if (!url.startsWith("http")) { toast(getString(R.string.download_unsupported)); return }
        val go = {
            val name = URLUtil.guessFileName(url, cd, mime)
            val req = DownloadManager.Request(Uri.parse(url)).apply {
                mime?.let { setMimeType(it) }
                CookieManager.getInstance().getCookie(url)?.let { addRequestHeader("Cookie", it) }
                ua?.let { addRequestHeader("User-Agent", it) }
                addRequestHeader("Referer", home)
                setTitle(name)
                setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED)
                setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, name)
                allowScanningByMediaScanner()
            }
            getSystemService(DownloadManager::class.java).enqueue(req)
            toast(getString(R.string.download_started, name))
        }
        if (Build.VERSION.SDK_INT <= 28 &&
            ContextCompat.checkSelfPermission(this, Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            pendingDownload = go; storagePerm.launch(Manifest.permission.WRITE_EXTERNAL_STORAGE)
        } else go()
    }

    // ---- Housekeeping ---------------------------------------------------------------------
    private fun setBars(show: Boolean) {
        val c = WindowCompat.getInsetsController(window, window.decorView)
        c.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        if (show) c.show(WindowInsetsCompat.Type.systemBars()) else c.hide(WindowInsetsCompat.Type.systemBars())
    }
    override fun onWindowFocusChanged(hasFocus: Boolean) { super.onWindowFocusChanged(hasFocus); if (hasFocus) setBars(false) }
    private fun toast(m: String) = Toast.makeText(this, m, Toast.LENGTH_SHORT).show()

    override fun onSaveInstanceState(out: Bundle) { super.onSaveInstanceState(out); if (!crashed) web.saveState(out) }
    override fun onPause() { if (!crashed) web.onPause(); super.onPause() }
    override fun onResume() { super.onResume(); if (!crashed) web.onResume() }
    override fun onDestroy() {
        try { unregisterReceiver(downloadDone) } catch (_: Exception) {}
        try { netCb?.let { getSystemService(ConnectivityManager::class.java).unregisterNetworkCallback(it) } } catch (_: Exception) {}
        if (!crashed) web.destroy()
        super.onDestroy()
    }
}
