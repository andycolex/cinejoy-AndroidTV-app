// D-pad spatial navigation + mouse-pointer mode + media control for cinejoy.pk on Android TV
(function () {
  if (window.__cj) return;
  var mode = 'focus', cx = 0, cy = 0, cur = null;
  var NATIVE = /^(A|BUTTON|INPUT|SELECT|TEXTAREA|SUMMARY|VIDEO|AUDIO)$/;
  var BASE = 'a[href],button,input:not([type=hidden]),select,textarea,summary,[tabindex]:not([tabindex="-1"]),[role=button],[role=link],[role=tab],[role=menuitem],[onclick]';
  var GENERIC = 'div,span,li,img,label,figure';
  var DIRS = { ArrowUp: [0, -1], ArrowDown: [0, 1], ArrowLeft: [-1, 0], ArrowRight: [1, 0] };

  var st = document.createElement('style');
  st.textContent = ':focus{outline:4px solid #E50914!important;outline-offset:3px!important}' +
    '*{-webkit-tap-highlight-color:transparent}::-webkit-scrollbar{display:none}';
  (document.head || document.documentElement).appendChild(st);

  function cands() {
    var out = [], seen = new Set();
    function add(e) {
      if (seen.has(e) || e.disabled) return;
      seen.add(e);
      var r = e.getBoundingClientRect();
      if (r.width < 4 || r.height < 4 || r.bottom < -innerHeight || r.top > innerHeight * 2 || r.right < 0 || r.left > innerWidth) return;
      var cs = getComputedStyle(e);
      if (cs.visibility === 'hidden' || cs.pointerEvents === 'none') return;
      out.push({ e: e, r: r });
    }
    document.querySelectorAll(BASE).forEach(add);
    document.querySelectorAll(GENERIC).forEach(function (e) {
      var p = e.parentElement;
      if (p && getComputedStyle(e).cursor === 'pointer' && getComputedStyle(p).cursor !== 'pointer') add(e);
    });
    return out;
  }
  function center(r) { return [r.left + r.width / 2, r.top + r.height / 2]; }

  function go(el) {
    if (!el.hasAttribute('tabindex') && !NATIVE.test(el.tagName)) el.setAttribute('tabindex', '-1');
    el.focus({ preventScroll: true });
    var r = el.getBoundingClientRect();
    if (r.top < 60 || r.bottom > innerHeight - 60 || r.left < 0 || r.right > innerWidth)
      el.scrollIntoView({ block: 'center', inline: 'center' });
  }

  function pick(dir) {
    var a = document.activeElement;
    var from = a && a !== document.body && a !== document.documentElement ? a : null;
    var list = cands(), best = null, bs = 1e12;
    if (!from) {
      list.forEach(function (c) {
        if (c.r.top < 0 || c.r.top > innerHeight) return;
        var s = c.r.top * 2 + c.r.left;
        if (s < bs) { bs = s; best = c; }
      });
    } else {
      var fr = from.getBoundingClientRect(), f = center(fr);
      list.forEach(function (c) {
        if (c.e === from || c.e.contains(from)) return;
        var cc = center(c.r), dx = cc[0] - f[0], dy = cc[1] - f[1], prim, sec;
        if (dir === 'ArrowLeft' || dir === 'ArrowRight') {
          prim = dir === 'ArrowRight' ? dx : -dx;
          sec = Math.min(fr.bottom, c.r.bottom) - Math.max(fr.top, c.r.top) > 0 ? 0 : Math.abs(dy);
        } else {
          prim = dir === 'ArrowDown' ? dy : -dy;
          sec = Math.min(fr.right, c.r.right) - Math.max(fr.left, c.r.left) > 0 ? 0 : Math.abs(dx);
        }
        if (prim < 2) return;
        var s = prim + sec * 2.5 + (sec === 0 ? 0 : 20);
        if (s < bs) { bs = s; best = c; }
      });
    }
    if (best) go(best.e);
    else if (dir === 'ArrowDown') scrollBy(0, innerHeight * 0.6);
    else if (dir === 'ArrowUp') scrollBy(0, -innerHeight * 0.6);
  }

  function place() { cur.style.left = cx + 'px'; cur.style.top = cy + 'px'; }
  function move(d, fast) {
    var s = fast ? 46 : 18;
    cx = Math.max(0, Math.min(innerWidth - 1, cx + d[0] * s));
    cy = Math.max(0, Math.min(innerHeight - 1, cy + d[1] * s));
    if (d[1] < 0 && cy < 40) scrollBy(0, -160);
    if (d[1] > 0 && cy > innerHeight - 40) scrollBy(0, 160);
    place();
  }
  function press() {
    var el = document.elementFromPoint(cx, cy);
    if (!el) return;
    ['mousedown', 'mouseup', 'click'].forEach(function (t) {
      el.dispatchEvent(new MouseEvent(t, { bubbles: true, cancelable: true, view: window, clientX: cx, clientY: cy }));
    });
    if (el.focus) el.focus();
  }

  window.addEventListener('keydown', function (e) {
    if (e.defaultPrevented) return;
    var k = e.key, d = DIRS[k];
    if (mode === 'cursor') {
      if (d) { move(d, e.repeat); e.preventDefault(); }
      else if (k === 'Enter') { press(); e.preventDefault(); }
      return;
    }
    var a = document.activeElement;
    if (k === 'Enter') {
      if (a && a !== document.body && !NATIVE.test(a.tagName)) { e.preventDefault(); a.click(); }
      return;
    }
    if (!d) return;
    var t = a && a.tagName, ty = a && a.type;
    var typing = a && (a.isContentEditable || t === 'TEXTAREA' ||
      (t === 'INPUT' && /^(text|search|email|url|tel|password|number)$/.test(ty)));
    if ((typing || ty === 'range') && d[1] === 0) return;  // keep caret / slider keys
    e.preventDefault();
    pick(k);
  }, false);

  window.__cj = {
    cursor: function (on) {
      if (on) {
        if (!cur) {
          cur = document.createElement('div');
          cur.style.cssText = 'position:fixed;z-index:2147483647;width:24px;height:24px;border-radius:50%;' +
            'background:rgba(229,9,20,.85);border:3px solid #fff;pointer-events:none;transform:translate(-50%,-50%)';
          document.documentElement.appendChild(cur);
        }
        cx = innerWidth / 2; cy = innerHeight / 2; place();
        cur.style.display = 'block'; mode = 'cursor';
      } else { if (cur) cur.style.display = 'none'; mode = 'focus'; }
    },
    media: function (a, v) {
      var vs = [].slice.call(document.querySelectorAll('video'));
      var m = vs.filter(function (x) { return !x.paused; })[0] || vs[0];
      if (!m) return;
      if (a === 'toggle') { if (m.paused) m.play(); else m.pause(); }
      else if (a === 'play') m.play();
      else if (a === 'pause') m.pause();
      else if (a === 'seek') m.currentTime = Math.max(0, Math.min(m.duration || 1e9, m.currentTime + v));
    }
  };
})();
